package BasicJava;

import java.sql.*;

public class connection {
    Connection myConn = null;
    Statement myStmt = null;
    ResultSet myRs = null;

    String dbUrl = "jdbc:mysql://localhost:3306/jdbc?useSSL=false";
    String user = "root";
    String pass = "mysql";

    public Connection getConnection() throws SQLException{

        myConn = DriverManager.getConnection(dbUrl, user, pass);

        System.out.println("Database connection successful!\n");

        return myConn;

    }
    public ResultSet executesql(String sql) throws SQLException{

        getConnection();
        myStmt = myConn.createStatement();

        System.out.println("Execute queries>>>>>>>>>>\n");
        myRs = myStmt.executeQuery(sql);

        return myRs;
        }
    public ResultSet updatesql(String sql) throws SQLException{

        getConnection();
        myStmt = myConn.createStatement();

        System.out.println(" Update the queries >>>>>>>>\n");
        int Rows = myStmt.executeUpdate(sql);
        ResultSet myRs_2 = myStmt.executeQuery("select * from cdw_sapp_customer");

        return myRs_2;
    }

    public void close_connection(Connection myConn, ResultSet myRs)throws SQLException{

            while(myRs.next()){
                if (myConn != null) {
                    myConn.close();
                }
            }
        }
}