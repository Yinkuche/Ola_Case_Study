package module;

import BasicJava.MyQuery;
import BasicJava.connection;
import Dao.customersDao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class customersDaoImpl implements customersDao
{
    public customersDaoImpl() {
        super();

    }
    ResultSet myRs = null;
    Connection myConn = null;



    @Override
    public void checkAccount(int ssn) throws SQLException{

        String sql = String.format(MyQuery.getAccountDetail,ssn);
        connection c1 = new connection();
        c1.getConnection();
        c1.executesql(sql);
        ResultSet myRs = c1.executesql(sql);
        Connection myConn = c1.getConnection();

        System.out.println("the result is: ");
        while(myRs.next()){
            System.out.println("             " + myRs.getString("first_name") + " " +
                    myRs.getString("middle_name")+ " " +  myRs.getString("last_name")+ " "+
                    myRs.getInt("ssn")+ " " + myRs.getString("credit_card_no") + " " +
                    myRs.getString("apt_no")+ " " + myRs.getString("street_name")+ " " +
                    myRs.getString("cust_city")+  " " + myRs.getString("cust_state") + " " +
                    myRs.getString("cust_country")+ " " + myRs.getString("cust_zip")+ " " + myRs.getInt("cust_phone")+ " " +
                    myRs.getString("cust_email")+  " " + myRs.getTimestamp("last_updated") + " " +
                    myRs.getInt("transaction_id")+ " " + myRs.getInt("day") + " " + myRs.getInt("month") + " " +
                    myRs.getInt("year")+ " " + myRs.getString("credit_card_no")+ " " +myRs.getInt("branch_code")+ " "+
                    myRs.getString("Transaction_type")+ " " + myRs.getBigDecimal("transaction_value"));

        }

        c1.close_connection(myConn, myRs);

    }

    @Override
    public void modifyAccount(String apt_no,String street_name, String cust_city, String cust_state, String cust_zip, int ssn) throws SQLException{

        String sql_2 = String.format(MyQuery.modifyAccountDetail,apt_no,street_name,cust_city,cust_state,cust_zip,ssn);
        connection c2 = new connection();
        Connection myConn_2 = c2.getConnection();
        ResultSet myRs_2  = c2.updatesql(sql_2);

        myRs_2.next();
        System.out.println(" Your updated information is  " + myRs_2.getString("first_name") + " " +
                    myRs_2.getString("middle_name")+ " " +  myRs_2.getString("last_name")+ " "+
                    myRs_2.getInt("ssn")+ " " + myRs_2.getString("credit_card_no") + " "
                    + myRs_2.getString("apt_no")+ " " + myRs_2.getString("street_name")+ " " +
                    myRs_2.getString("cust_city")+  " " + myRs_2.getString("cust_state") + " "
                    + myRs_2.getString("cust_country")+ " " + myRs_2.getString("cust_zip")+ " " + myRs_2.getInt("cust_phone")+ " " +
                    myRs_2.getString("cust_email")+  " " + myRs_2.getTimestamp("last_updated"));

        c2.close_connection(myConn_2,myRs_2);
    }

    @Override
    public void getMonthlyBill(String credit_card_no, int month, int year) throws SQLException {

        String sql_3 = String.format(MyQuery.getMonthlyBill,credit_card_no,month,year);
        connection c3 = new connection();

        Connection myConn_3 = c3.getConnection();
        ResultSet myRs_3 = c3.executesql(sql_3);


        System.out.println("The monthly bill you slected is :  " + "Month" + " " + "Year" +" " + "Credit_card_no"+ "    "+"Total_bill");
        while(myRs_3.next()){
            System.out.println("                                   " +
                    " " + myRs_3.getInt("month") + "    " +
                    myRs_3.getInt("year")+ "  "+ myRs_3.getString("credit_card_no")+ "  "+
                    myRs_3.getBigDecimal("Total_bill"));
        }
        c3.close_connection(myConn_3, myRs_3);


        }



    @Override
    public void  checkTransactionBetweenDates(int year1, int month1, int day1, int year2, int month2, int day2, String first_name, String last_name) throws SQLException{

        String sql_4 = String.format(MyQuery.getTransactionBetweenTwoDates,year1, month1,day1,year2, month2,day2,first_name, last_name);
        connection c4 = new connection();

        Connection myConn_4 = c4.getConnection();
        ResultSet myRs_4 = c4.executesql(sql_4);


        System.out.println("the transaction detail is: ");
        while(myRs_4.next()){
            System.out.println("                           " + myRs_4.getString("first_name") + " " +  myRs_4.getString("last_name")+ " "+
                myRs_4.getInt("transaction_id")+ " "+ myRs_4.getString("Transaction_type")+ " " + myRs_4.getBigDecimal("transaction_value") + " " +
                myRs_4.getDate("dates"));
        }


        c4.close_connection(myConn_4, myRs_4);

    }
}

